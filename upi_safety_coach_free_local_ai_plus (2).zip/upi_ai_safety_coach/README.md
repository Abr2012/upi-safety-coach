# UPI Safety Coach AI — Free local AI version

This version uses **Ollama** to run an AI model locally on your Windows computer. It does not use OpenAI API billing, an API key, or a payment card. The model download uses disk space and performance depends on your computer.

## 1. Install Ollama

Download Ollama for Windows from the official site: https://ollama.com/download/windows
Install it and open the Ollama app. Official Windows docs: https://github.com/ollama/ollama/blob/main/docs/windows.mdx

## 2. Download a model

Open a new Command Prompt and run:

```bat
ollama run llama3.2:3b
```

The first run downloads the model, so it can take a while and uses several GB of disk space. When it opens a chat prompt, type ` /bye ` and press Enter to exit. Keep the Ollama app running in the background. If your computer has limited memory, the model may run slowly.

## 3. Install this app's Python packages

Open Command Prompt in the folder containing `app.py` and run:

```bat
py -m pip install -r requirements.txt
```

## 4. Start UPI Safety Coach

From the same folder, run:

```bat
py -m streamlit run app.py
```

Open the local URL Streamlit shows, usually `http://localhost:8501`.

## If the model name needs changing

The app defaults to `llama3.2:3b`. If you downloaded a different Ollama model, set its exact name before starting Streamlit, for example:

```bat
set OLLAMA_MODEL=llama3.2:3b
py -m streamlit run app.py
```

## Important safety notes

- No OpenAI API key or payment is needed for this local version.
- The model runs locally, so the description is sent to Ollama on your own computer, not to OpenAI's API. Internet is needed to download Ollama/model and for any Streamlit access that requires it, but normal local model inference works offline once installed.
- Never enter a real UPI PIN, OTP, password, bank account number, card number, or other private information.
- AI can make mistakes and cannot verify bank transactions. Always verify independently through official bank/payment-app channels.
- If you suspect cyber financial fraud in India, contact your bank through official channels and report promptly via 1930 and cybercrime.gov.in.
